# Platform-Hero
A simple 2D platformer Game made in Unity
CS 108
Authors: Nicholas Burnam and Patty Ngo
